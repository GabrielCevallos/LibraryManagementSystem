public class User extends Person{
    private String id;
    private boolean enabled;

}
