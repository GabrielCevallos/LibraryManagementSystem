package Structure;

public class Rack {
    private int number;
    private int quantityBooks;
    private int quantityMagazines;
    private int quantityPublications;

    //relations
    private Section section;

    public Rack(int number, int quantityBooks, int quantityMagazines, int quantityPublications, Section section) {
        this.number = number;
        this.quantityBooks = quantityBooks;
        this.quantityMagazines = quantityMagazines;
        this.quantityPublications = quantityPublications;
        this.section = section;
    }

    public int getNumber() {
        return number;
    }

    public int getQuantityBooks() {
        return quantityBooks;
    }

    public int getQuantityMagazines() {
        return quantityMagazines;
    }

    public int getQuantityPublications() {
        return quantityPublications;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public void setQuantityBooks(int quantityBooks) {
        this.quantityBooks = quantityBooks;
    }

    public void setQuantityMagazines(int quantityMagazines) {
        this.quantityMagazines = quantityMagazines;
    }

    public void setQuantityPublications(int quantityPublications) {
        this.quantityPublications = quantityPublications;
    }
}
