package Structure;

public class Library {
}
