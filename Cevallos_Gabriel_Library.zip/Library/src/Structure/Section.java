package Structure;

import java.util.ArrayList;

public class Section {
    private int name;
    private int amountPublications;
    private int amountBooks;
    private int amountMagazines;

    //relations
    private ArrayList<Rack> racks;

    public Section(int name, int amountPublications, int amountBooks, int amountMagazines) {
        this.name = name;
        this.amountPublications = amountPublications;
        this.amountBooks = amountBooks;
        this.amountMagazines = amountMagazines;
        this.racks = new ArrayList<>();
    }
    //
    public int getName() {
        return name;
    }
}
