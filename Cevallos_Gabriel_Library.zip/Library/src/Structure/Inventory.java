package Structure;

import java.util.Date;

public class Inventory {
    private Date lastUpdate;
    private int quantityPublications;
    private int quantityBooks;
    private int quantityMagazines;

    private Library library;
}
