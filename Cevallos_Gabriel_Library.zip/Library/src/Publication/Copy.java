package Publication;

import Structure.Rack;
import Structure.Section;

public class Copy {
    private int code;
    private String publicationDate;
    public static int copyCounter = 0;
    private CopyState state;
    private boolean isAvailable;
    private boolean isLendable;

    //relations
    private Book book;
    private Section section;
    private Rack rack;

    public Copy(String publicationDate, CopyState state, boolean isLent, boolean isLendable, Book book, Section section, Shelf shelf) {
        this.code = copyCounter++;
        this.publicationDate = publicationDate;
        this.state = state;
        this.isAvailable = isLent;
        this.isLendable = isLendable;
        this.book = book;
        this.section = section;
        this.rack = rack;
    }

    public int getCode() {
        return code;
    }

    public String getPublicationDate() {
        return publicationDate;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public void setPublicationDate(String publicationDate) {
        this.publicationDate = publicationDate;
    }

    public void setState(CopyState state) {
        this.state = state;
    }

    public boolean isAvailable() {
        return isAvailable;
    }

    public void setIsAvailable(boolean isLent) {
        this.isAvailable = isLent;
    }

    public boolean isLendable() {
        return isLendable;
    }
}
