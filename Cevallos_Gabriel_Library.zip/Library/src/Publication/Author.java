package Publication;

public class Author {
    private String name;
    private String lastName;
    private String nacionality;

    public Author(String name, String lastName, String nacionality) {
        this.name = name;
        this.lastName = lastName;
        this.nacionality = nacionality;
    }

    public String getName() {
        return name;
    }

    public String getLastName() {
        return lastName;
    }

    public String getNacionality() {
        return nacionality;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setNacionality(String nacionality) {
        this.nacionality = nacionality;
    }

    @Override
public String toString() {
        return "Author{" +
                "name='" + name + '\'' +
                ", lastName='" + lastName + '\'' +
                ", nacionality='" + nacionality + '\'' +
                '}';
    }

}
