package Publication;

public class Magazine extends Publication {
    private int number;
    private int volume;

    //relations
    private Category category;

    public Magazine(String title, String publicationDate, String editorial, Author author, int number, int volume, Category category) {
        super(title, publicationDate, editorial, author);
        this.number = number;
        this.volume = volume;
        this.category = category;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public int getVolume() {
        return volume;
    }

    public void setVolume(int volume) {
        this.volume = volume;
    }

    @Override
    public String toString() {
        return "Magazine{" +
                "Title='" + title + '\'' +
                ", Publication Date='" + publicationDate + '\'' +
                ", Editorial='" + editorial + '\'' +
                ", Author=" + author +
                ", number=" + number +
                ", volume=" + volume +
                ", category=" + category +
                '}';
    }
}
