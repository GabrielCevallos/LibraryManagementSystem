package Publication;

public enum State {
    NEW, USED, BAD;
}
