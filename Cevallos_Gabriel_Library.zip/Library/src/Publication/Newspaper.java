package Publication;

public class Newspaper extends Publication {

    public Newspaper(String title, String publicationDate, String editorial, Author author) {
        super(title, publicationDate, editorial, author);
    }
}
