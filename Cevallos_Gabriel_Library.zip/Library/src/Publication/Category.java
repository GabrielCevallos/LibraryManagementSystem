package Publication;

public enum Category {
    TECHNOLOGY, MEDICINE, ACADEMIC;
}
