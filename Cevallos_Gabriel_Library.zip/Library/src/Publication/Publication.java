package Publication;

public abstract class Publication {
    protected String title;
    protected String publicationDate;
    protected String editorial;

    //Relations
    protected Author author;

    public Publication(String title, String publicationDate, String editorial, Author author) {
        this.title = title;
        this.publicationDate = publicationDate;
        this.editorial = editorial;
        this.author = author;
    }

    public Author getAuthor() {
        return author;
    }

    public void setAuthor(Author author) {
        this.author = author;
    }
}
