package Publication;

public enum Genre {
    LITERATURE, ACADEMIC, ENCYCLOPEDIA, SCIENTIFIC;
}
