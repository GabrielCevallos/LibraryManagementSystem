package Publication;

public class Book {
    private String isbn;
    private int pages;
    private int chapters;
    private String description;

    //relations
    public Genre genre;

    public Book(String title, String publicationDate, String editorial, Author author, String isbn, int pages, int chapters, String description, Genre genre) {
        super();
        this.isbn = isbn;
        this.pages = pages;
        this.chapters = chapters;
        this.description = description;
        this.genre = genre;

    }

    public Genre getGenre() {
        return genre;
    }

    public void setGenre(Genre genre) {
        this.genre = genre;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getPages() {
        return pages;
    }

    public void setPages(int pages) {
        this.pages = pages;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public int getChapters() {
        return chapters;
    }

    public void setChapters(int chapters) {
        this.chapters = chapters;
    }
}
