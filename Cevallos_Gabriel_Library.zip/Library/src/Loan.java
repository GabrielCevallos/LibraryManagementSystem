public class Loan {
}
