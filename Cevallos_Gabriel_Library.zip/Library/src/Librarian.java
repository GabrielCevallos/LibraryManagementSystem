import Publication.Book;

public class Librarian extends Person implements MainTasks {
    private String id;

    @Override
    public void addUser() {

    }

    @Override
    public void modifyUser() {

    }

    @Override
    public void removeUser() {

    }

    @Override
    public void lendBook() {

    }

    @Override
    public void returnBook() {

    }

    @Override
    public void placeBook(Book book) {

    }

    @Override
    public void searchBook() {

    }
}
