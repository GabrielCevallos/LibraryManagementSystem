public abstract class Person {
    protected String name;
    protected String lastName;
    protected String dni;
    protected String direction;

}
