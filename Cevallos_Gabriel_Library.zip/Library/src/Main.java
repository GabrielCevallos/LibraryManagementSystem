import Publication.Author;
import Publication.Book;
import Publication.Copy;
import Publication.Magazine;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        Author author = new Author("J.K. Rowling", "United Kingdom", "British");
        Magazine magazine = new Magazine("Harry Potter", "12/12/2020", "Scholastic", author, 12, 1, Category.FICTION);
        System.out.println(magazine);

        Book book = new Book("Harry Potter", "12/12/2020", "Scholastic", author, "123456", 200, 10, "Fiction", Genre.FICTION);
        System.out.println(book);

        Copy copy = new Copy("12/12/2020", CopyState.NEW, false, true, book, null, null);
    }
}