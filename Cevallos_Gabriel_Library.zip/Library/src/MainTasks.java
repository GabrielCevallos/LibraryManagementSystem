import Publication.Book;

public interface MainTasks {
    public void addUser();
    public void modifyUser();
    public void removeUser();
    public void lendBook();
    public void returnBook();
    public void placeBook(Book book);
    public void searchBook();
}
